import homepage from "./pages/home.page";

describe("Icon", () => {
    it("should render a div with text", () => {
        homepage.open();

        /**
         * Create your tests here. Example:
         * homepage.div.waitForVisible();
         * const widgetValue = homepage.div.getText();
         * expect(widgetValue).toContain("Hello ");
         */
    });
});
