import * as WebdriverIO from "webdriverio";
declare var browser: WebdriverIO.Client<void>;
